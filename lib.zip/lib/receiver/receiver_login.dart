import 'package:flutter/material.dart';

import '../functions/auth_functions.dart';  // Make sure to implement receiver-related auth functions
import 'receiver_dashboard.dart';  // Create a Receiver Dashboard screen for successful login

class ReceiverLoginPage extends StatefulWidget {
  const ReceiverLoginPage({Key? key}) : super(key: key);

  @override
  State<ReceiverLoginPage> createState() => _ReceiverLoginPageState();
}

class _ReceiverLoginPageState extends State<ReceiverLoginPage> {
  final _formKey = GlobalKey<FormState>();

  String email = '';
  String password = '';
  String receiverName = '';
  String address = '';
  String phone = '';  // Receiver-specific detail
  bool isLogin = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isLogin ? 'Receiver Login' : 'Receiver Signup'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(14),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (!isLogin)
                  TextFormField(
                    key: const ValueKey('receiverName'),
                    decoration: const InputDecoration(
                      hintText: 'Enter Receiver Name',
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please Enter a Receiver Name';
                      } else {
                        return null;
                      }
                    },
                    onSaved: (value) {
                      setState(() {
                        receiverName = value!;
                      });
                    },
                  ),
                 if (!isLogin)
                  TextFormField(
                    key: ValueKey('receiverAddress'),
                    decoration: InputDecoration(
                      hintText: 'Enter your Address',
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please Enter your Address';
                      }
                      return null; 
                    },
                    onSaved: (value) {
                      address = value!;
                    },
                  ),
                  if (!isLogin)
                TextFormField(
                  key: ValueKey('receiverPhone'),
                  decoration: InputDecoration(
                    hintText: 'Enter Phone Number',
                  ),
                  validator: (value) {
                    if (value!.length<10) {
                      return 'Please Enter a valid Phone Number';
                    }
                    return null; // Return null if validation passes
                  },
                  onSaved: (value) {
                    phone = value!;
                  },
                ), 
                TextFormField(
                  key: const ValueKey('receiverEmail'),
                  decoration: const InputDecoration(
                    hintText: 'Enter Email',
                  ),
                  validator: (value) {
                    if (value!.isEmpty || !value.contains('@')) {
                      return 'Please Enter a valid Email';
                    } else {
                      return null;
                    }
                  },
                  onSaved: (value) {
                    setState(() {
                      email = value!;
                    });
                  },
                ),
                TextFormField(
                  key: const ValueKey('password'),
                  obscureText: true,
                  decoration: const InputDecoration(
                    hintText: 'Enter Password',
                  ),
                  validator: (value) {
                    if (value!.length < 6) {
                      return 'Password must be at least 6 characters';
                    } else {
                      return null;
                    }
                  },
                  onSaved: (value) {
                    setState(() {
                      password = value!;
                    });
                  },
                ),
                const SizedBox(height: 30),
                SizedBox(
                  height: 55,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        if (isLogin) {
                          final userCredential = await ReceiverAuthServices.signinReceiver(
                              email, password, context);
                          if (userCredential != null) {
                            // Navigate to Receiver Dashboard
                            Navigator.pushReplacement(context, MaterialPageRoute(
                                builder: (context) => const ReceiverDashboard()));
                          }
                        } else {
                          final userCredential = await ReceiverAuthServices.signupReceiver(
                              email, password, receiverName, context);
                          if (userCredential != null) {
                            // Navigate to Receiver Dashboard
                            Navigator.pushReplacement(context, MaterialPageRoute(
                                builder: (context) => const ReceiverDashboard()));
                          }
                        }
                      }
                    },
                    child: Text(isLogin ? 'Login' : 'Signup'),
                  ),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: () {
                    setState(() {
                      isLogin = !isLogin;
                    });
                  },
                  child: Text(
                    isLogin
                        ? "Don't have an account? Signup"
                        : "Already have an account? Login",
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
