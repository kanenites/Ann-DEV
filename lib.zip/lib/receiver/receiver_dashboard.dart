import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:waste_manage/user_type.dart';

class ReceiverDashboard extends StatefulWidget {
  const ReceiverDashboard({Key? key}) : super(key: key);

  @override
  _ReceiverDashboardState createState() => _ReceiverDashboardState();
}

class _ReceiverDashboardState extends State<ReceiverDashboard> {
  late List<ContributorData> _contributors = [];

  @override
  void initState() {
    super.initState();
    _loadContributors();
  }

  Future<void> _loadContributors() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('contributors').get();
    final contributorsData = snapshot.docs
        .map((doc) => ContributorData.fromSnapshot(doc))
        .toList();
    setState(() {
      _contributors = contributorsData;
    });
  }

  void _bookWaste(ContributorData contributor) {
    // Mark the waste as booked in Firestore
    FirebaseFirestore.instance.collection('bookings').add({
      'contributorEmail': contributor.email,
      'solidFood': contributor.solidFood,
      'liquidFood': contributor.liquidFood,
      'foodDescription': contributor.foodDescription, // Add food description
      'receiverEmail': FirebaseAuth.instance.currentUser!.email,
      'timestamp': FieldValue.serverTimestamp(),
    }).then((_) {
      // Update the contributor document to mark it as booked
      FirebaseFirestore.instance
          .collection('contributors')
          .doc(contributor.docId)
          .update({'booked': true}).then((_) {
        setState(() {
          contributor.booked = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Food booked successfully!')),
        );
      });
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to book food: $error')),
      );
    });
  }

  Future<void> _signOut() async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => UserTypePage()),
      (Route<dynamic> route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Receiver Dashboard'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: _signOut,
          ),
        ],
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/images2.jpg'), // Background image
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(
                  Colors.black.withOpacity(0.3),
                  BlendMode.darken,
                ),
              ),
            ),
          ),
          ListView.builder(
            itemCount: _contributors.length,
            itemBuilder: (context, index) {
              return ContributorCard(
                contributor: _contributors[index],
                onBook: _contributors[index].booked
                    ? null
                    : () => _bookWaste(_contributors[index]),
              );
            },
          ),
        ],
      ),
    );
  }
}

class ContributorCard extends StatelessWidget {
  final ContributorData contributor;
  final VoidCallback? onBook;

  const ContributorCard({required this.contributor, this.onBook, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: Colors.white.withOpacity(0.4), // Set background color to white with opacity
      elevation: 0, // Remove elevation to make it flat
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10), // Rounded corners if needed
      ),
      child: ListTile(
        title: Text(
          contributor.name,
          style: const TextStyle(color: Colors.white),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Email: ${contributor.email}', style: const TextStyle(color: Colors.white)),
            Text('Solid Food: ${contributor.solidFood?.toStringAsFixed(2) ?? 0.0} kg',
                style: const TextStyle(color: Colors.white)),
            Text('Liquid Food: ${contributor.liquidFood?.toStringAsFixed(2) ?? 0.0} liters',
                style: const TextStyle(color: Colors.white)),
            Text('Description: ${contributor.foodDescription}', style: const TextStyle(color: Colors.white)), // Add food description
          ],
        ),
        trailing: ElevatedButton(
          onPressed: onBook,
          child: Text(contributor.booked ? 'Already Booked' : 'Book'),
          style: ElevatedButton.styleFrom(
            backgroundColor: contributor.booked ? Colors.grey : null,
          ),
        ),
      ),
    );
  }
}

class ContributorData {
  final String name;
  final String email;
  final double? solidFood;
  final double? liquidFood;
  bool booked; // Add a booked flag
  final String docId; // Store document ID for easy updates
  final String foodDescription; // Add a food description field

  ContributorData({
    required this.name,
    required this.email,
    this.solidFood,
    this.liquidFood,
    required this.booked,
    required this.docId,
    required this.foodDescription, // Add food description to constructor
  });

  factory ContributorData.fromSnapshot(DocumentSnapshot snapshot) {
    final data = snapshot.data() as Map<String, dynamic>;
    return ContributorData(
      name: data['name'] ?? '',
      email: data['email'] ?? '',
      solidFood: double.tryParse(data['solidFood']?.toString() ?? '0.0'),
      liquidFood: double.tryParse(data['liquidFood']?.toString() ?? '0.0'),
      booked: data['booked'] ?? false, // Fetch booked status from Firestore
      docId: snapshot.id, // Store document ID
      foodDescription: data['foodDescription'] ?? 'No description available', // Fetch food description
    );
  }
}
